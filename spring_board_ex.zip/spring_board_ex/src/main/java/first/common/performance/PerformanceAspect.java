package first.common.performance;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect 
public class PerformanceAspect { 	
	protected Log log = LogFactory.getLog(PerformanceAspect.class);
	
	@Around("execution(* first..dao.*DAO.*(..))") 
	public Object calculatePerformanceTime(ProceedingJoinPoint joinPoint) { 
		Object result = null; 
		try { 
			long start = System.currentTimeMillis(); 
			result = joinPoint.proceed(); 
			long end = System.currentTimeMillis(); 
			
			log.debug(" Performance \t:  수행 시간  "+ (end - start) + "ms");
		} catch (Throwable throwable) { 
			log.debug(" Performance calculate \t:  exception! ");
		} 
		return result; 
	}

}