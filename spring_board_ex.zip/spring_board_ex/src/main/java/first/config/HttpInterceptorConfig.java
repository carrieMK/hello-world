package first.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry; 
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import first.common.logger.LoggerInterceptor;
import first.common.login.LoginInterceptor; 

@EnableWebMvc
@Configuration 
public class HttpInterceptorConfig extends WebMvcConfigurerAdapter { 
	
	@Autowired
	private LoggerInterceptor loggerInterceptor;
	
	@Autowired
	private LoginInterceptor loginInterceptor;
	
	@Override 
	public void addInterceptors(InterceptorRegistry registry) { 
		registry.addInterceptor(loggerInterceptor).addPathPatterns("/**"); 
		registry.addInterceptor(loginInterceptor).addPathPatterns("/sample/**");
		} 
	}
