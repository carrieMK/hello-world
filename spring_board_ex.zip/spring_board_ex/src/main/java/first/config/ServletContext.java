package first.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@Import({HttpInterceptorConfig.class})
@ImportResource({"/WEB-INF/config/action-servlet.xml"})
public class ServletContext {

}
